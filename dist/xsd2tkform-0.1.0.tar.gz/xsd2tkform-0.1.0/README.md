# XSD 2 Tk form 

(Still in developpement, new release to come soon)

Tool for generating Tkinter forms from XML schemas.

Implement a simple XML editor that can produce valid XML for a given schema.


